const Index = () => {
  return <h1>hello</h1>;
};

export default Index;
